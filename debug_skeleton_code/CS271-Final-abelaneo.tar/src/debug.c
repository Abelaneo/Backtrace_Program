#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>

#include "debug.h"

char const *regnames[] = {
    "rax",
    "rbx",
    "rcx",
    "rdx",
    "rsi",
    "rdi",
    "rbp",
    "rsp",
    "r8",
    "r9",
    "r10",
    "r11",
    "r12",
    "r13",
    "r14",
    "r15",
};

/* Internal helper function for dump_registers */
void
_debug_dump_registers(long const *regs)
{
	for (int i = 0; i < 16; i++) {
		printf("%s\t%ld (0x%lx)\n", regnames[i], regs[i], regs[i]);
	}
}

/* Internal helper function for backtrace */
void
_debug_dump_backtrace(int chain_count, void* rbp) 
{
	Dl_info info;
	dladdr((void*)rbp, &info);
	printf("%3ld: [%lx] %s () %s\n", chain_count, info.dli_saddr,
		info.dli_sname, info.dli_fname);
}

